marketing-agency/
├── index.html
├── styles/
│   ├── main.css
│   └── auth.css
├── scripts/
│   ├── main.js
│   └── auth.js
├── images/
│   ├── hero-bg.jpg
│   ├── services/
│   └── team/
├── dashboard.html
└── README.md